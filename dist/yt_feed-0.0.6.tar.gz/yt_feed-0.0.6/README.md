# Installing

```bash
python3.10 -m pip install yt-feed
```
now add your channels to the config file and get the feed with `yt-feed`


